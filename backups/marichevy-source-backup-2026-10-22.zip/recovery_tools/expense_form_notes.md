PR4 expense form handoff

Apply after PR3:

    python /workspace/expense_form_patch.py /workspace/marichevy-finance/index.html /workspace/pr4-integrated.html
    python /workspace/marichevy-finance/tests/test_expense_form.py --html /workspace/pr4-integrated.html

The transform requires a separate output and rejects repeat application. The root agent owns applying the reviewed HTML to index.html and committing; this agent did neither.

Form: operation chooser remains for existing income/transfer/cash flow. Expense fields run amount → purchase search → beneficiary → optional visible merchant. Date defaults today; date, payment, comment and optional existing subcategory stay in Details. No payer field. Beneficiary defaults Общее and reuses existing PEOPLE values, including Дени and Макс. Existing edit dialog retains legacy/unknown recipient and category options.

Quick choices reuse existing keys: snacks → Вкусняшки; school food, English and dance → Школа и занятия with existing details; feed → Животные/Корм; gift → Подарки; restaurant and tips → Рестораны и кафе. Tips uses a comment, without adding a new category or subcategory. Plain text search still uses existing v92Matches and purchase vocabulary. All existing categories remain under Все категории. No persisted-category migration or historical rewrite.

CSS: remove superseded entry-form rules from their current style blocks, including old v82/v90/v91/v92 grid/chip rules, then define the scoped component once without !important. Mixed selector rules keep unrelated selectors; nested media blocks keep unrelated content. History, dashboard, transactions, main/nav responsive behavior remain in place. No global stylesheet cleanup.

Validation: 7 targeted browser regressions pass on the transformed current HTML. Synthetic local state, session=null, outbound requests blocked, no backend/prod/deploy operations. Checks cover defaults/order, quick cases, plain search, same snacks category with two beneficiaries, unchanged history, income/transfer save, unknown edit values, and field bounds at1280/390/320. Temp screenshots visually inspected at1440/390; artifact names /workspace/artifacts/pr4-form-desktop.png and pr4-form-mobile.png. Root should regenerate final screenshots after integration.
