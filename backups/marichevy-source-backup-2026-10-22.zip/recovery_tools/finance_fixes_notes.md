PR3 handoff

Apply after PR2 to preserve its deterministic confirmation IDs/paymentKey:

    python /workspace/finance_patch.py index.html /tmp/finance-final.html
    python tests/test_financial_integrity.py --html /tmp/finance-final.html

The transform edits v77PayPart in place: ID/paymentKey creation remains untouched. It fails closed if the expected actual-date/type fragment cannot be adapted. The old plan receives accountingMode only after an explicit 1/2 choice and confirmation. Existing linked partial entries are corrected explicitly in history; another confirmation does not silently replace them.

Validation: 18 browser regressions; 14 fail as assertions on original e6befd6, all 18 pass on transformed current 4aa2c75. See /tmp/finance-red.txt and /tmp/finance-green.txt. Baseline /tmp/finance-original-e6befd6.html. Repository index.html has not been edited by this stream.

Coverage: actual edited/deleted/overpaid allocation, actual payment date with planned metadata, two accounting modes and cancellation, preservation of equal unlinked historical 4608 expense, overdue forecast and explicit linked-part dedup, beneficiary totals/filter, transfer-only and income-only adviser basis, incomplete-income labeling, exact zero-extra pinned schedule including charges, partial/full/overpayment in both strategies, later unused extras and matching UI summaries.

Conservative choices made explicit in UI: recurring plans lack historical activation dates, so forecast includes current-period overdue recurring payments and all stored overdue installment/mortgage dates, without manufacturing earlier recurring instances. Coincident dates/amounts never imply duplicate obligations. Entered early amount is principal contribution; accrued interest is separate required cash, while unused principal surplus and bank extra charges are separately displayed. Estimates do not change the pinned bank schedule or historical operations and instruct the user to obtain the bank payoff quote.
