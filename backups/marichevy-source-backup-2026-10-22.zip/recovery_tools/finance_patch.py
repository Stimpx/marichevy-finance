"""Targeted PR3 HTML transform. Never writes the repository unless given that path explicitly."""
from pathlib import Path
import re
import sys


def replace_function(html, name, body):
    match = re.search(r'(?:async )?function '+re.escape(name)+r'\(', html)
    if not match:
        raise ValueError('Missing function '+name)
    end = re.search(r'\n(?:async )?function |\nconst V77_KINDS=', html[match.end():])
    if not end:
        raise ValueError('No boundary '+name)
    stop = match.end()+end.start()
    # Preserve comments between functions by ending at the final function brace.
    old = html[match.start():stop]
    brace = old.rfind('\n}')
    if brace >= 0:
        stop = match.start()+brace+2
    else:
        stop = match.start()+len(old)
    return html[:match.start()]+body.rstrip()+html[stop:]


def patch(html):
    def fn(name, body):
        nonlocal html
        html = replace_function(html, name, body)
    def sub(old,new):
        nonlocal html
        if old not in html: raise ValueError('Missing text '+old[:100])
        html=html.replace(old,new)

    fn('v94ExpenseBucket', '''function v94ExpenseBucket(e){return v86ExpenseTarget(e)}''')
    sub("'Денни':0,'Кредиты и рассрочки':0,'Автомобиль':0,'Общее':0", "'Дени':0,'Общее':0")
    sub("(!who||e.who===who)", "(!who||(e.type==='expense'?v86ExpenseTarget(e):e.who)===who)")
    sub("esc(e.who)} · ${esc(e.comment||'')}", "esc(e.type==='expense'?v86ExpenseTarget(e):e.who)} · ${esc(e.comment||'')}")
    # A linked expense is only paid to the extent of its current actual value.
    # Debt movements are accepted only when explicitly flagged as such.
    fn('installmentLinkedEntry', '''function installmentLinkedEntry(i,part){
 const ref=i?.links?.[part.id];return ref?(state.entries||[]).find(e=>e.id===ref&&(e.type==='expense'||(e.type==='transfer'&&e.debtRepayment===true))):null;
}
function installmentAllocated(i,part){
 const e=installmentLinkedEntry(i,part),amount=Number(e?.amount)||0;
 return Math.max(0,Math.min(v77Cents(part.amount),v77Cents(amount)))/100;
}''')
    fn('installmentPaid', '''function installmentPaid(i,part){return v77Cents(installmentAllocated(i,part))>=v77Cents(part.amount)}''')
    sub("(installmentPaid(i,p)?v77Cents(p.amount):0)", "v77Cents(installmentAllocated(i,p))")
    sub("const paid=!!installmentLinkedEntry((state.installments||[]).find(i=>(i.parts||[]).some(part=>part.id===p.id)),p);", "const plan=(state.installments||[]).find(i=>(i.parts||[]).some(part=>part===p)),allocated=installmentAllocated(plan,p),paid=installmentPaid(plan,p);")
    sub("amount:p.amount,paid,late:p.date<todayKey&&!paid", "amount:p.amount,allocated,partial:allocated>0&&!paid,paid,late:p.date<todayKey&&!paid")
    sub("amount:Number(p.amount)||0}))).sort", "amount:Math.max(0,(Number(p.amount)||0)-installmentAllocated(i,p))}))).sort")
    sub("(installmentPaid(i,p)?0:Number(p.amount)||0)", "Math.max(0,(Number(p.amount)||0)-installmentAllocated(i,p))")
    sub("(installmentPaid(i,p)?Number(p.amount)||0:0)", "installmentAllocated(i,p)")
    sub("remaining=left.reduce((a,p)=>a+Number(p.amount),0)", "remaining=left.reduce((a,p)=>a+Math.max(0,Number(p.amount)-installmentAllocated(i,p)),0)")
    sub("const linked=installmentLinkedEntry(i,p);return", "const linked=installmentLinkedEntry(i,p),allocated=installmentAllocated(i,p),fullyPaid=installmentPaid(i,p);return")
    sub("${linked?'paid':''}", "${fullyPaid?'paid':''}")
    sub("${linked?'· ✓ Учтено в расходах':'· Ожидает оплаты'}", "${fullyPaid?'· ✓ Оплачено':allocated>0?'· Частично: '+money2(allocated)+' · остаток '+money2(Number(p.amount)-allocated):'· Ожидает оплаты'}")
    # A partial existing operation must be edited explicitly, never silently replaced.
    # PR2 owns confirmation IDs/atomic persistence: transform its body in place.
    start=html.index('function v77PayPart(')
    stop=html.index('\nfunction v77ShowMatches(', start)
    body=html[start:stop]
    body=body.replace("if(!i||!part||installmentPaid(i,part))return;", "if(!i||!part||installmentPaid(i,part))return;\n if(installmentLinkedEntry(i,part)){toast('Часть оплачена частично. Измените связанную операцию в истории; новая оплата автоматически не создаётся.');return}\n let accountingMode=i.accountingMode;\n if(!['payments','purchase'].includes(accountingMode)){\n  const choice=window.prompt('Как учитывать эту покупку? Введите 1 — считаем расходы по платежам; 2 — покупка уже записана целиком, оплата только погашает долг. Отмена не создаёт операцию.','');\n  accountingMode=choice==='1'?'payments':choice==='2'?'purchase':null;\n  if(!['payments','purchase'].includes(accountingMode)){toast('Выберите способ учёта: 1 или 2');return}\n }")
    body=body.replace("date:part.date>today()?today():part.date,type:'expense'", "date:today(),scheduledDate:part.date,type:accountingMode==='purchase'?'transfer':'expense',debtRepayment:accountingMode==='purchase',accountingMode")
    # Mode is metadata of this explicitly confirmed plan, never inferred from history.
    body=body.replace("i.updated_at=now;", "i.accountingMode=accountingMode;i.updated_at=now;")
    body=body.replace("if(!window.confirm('Создать расход '+money2(part.amount)+' по покупке «'+i.title+'»? Если он уже есть в истории, выберите «Из истории» вместо этого.'))return;", "if(!window.confirm((accountingMode==='purchase'?'Записать погашение долга ':'Создать расход ')+money2(part.amount)+' по покупке «'+i.title+'» датой сегодня? Если оплата уже есть в истории, отмените и выберите «Из истории».'))return;")
    body=body.replace("toast('✓ Оплата записана в расходы один раз')", "toast(accountingMode==='purchase'?'✓ Погашение долга записано без нового расхода':'✓ Оплата записана в расходы один раз')")
    if 'scheduledDate:part.date' not in body: raise ValueError('Adapt PR2 payment body before applying')
    html=html[:start]+body+html[stop:]
    fn('v87AdvisorMonths', '''function v87AdvisorMonths(){
 const current=month(),months=[],first=current+'-01T12:00:00';
 for(let i=1;i<=3;i++){const d=new Date(first);d.setMonth(d.getMonth()-i);months.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`)}
 let available=months.filter(m=>expenses(m).length>0),provisional=false;
 if(!available.length&&expenses(current).length){available=[current];provisional=true}
 return {months:available,provisional,current};
}''')
    sub("if(d.partialIncome)status.textContent+=", "if(!d.hasIncome&&!d.partialIncome)status.textContent+=' Доходы не внесены: сравнение с зарплатой недоступно.';\n if(d.partialIncome)status.textContent+=")
    sub("['Средние доходы',d.hasIncome?money(d.income):'Нет записей'", "['Средние доходы',d.hasIncome?money(d.income):d.partialIncome?'Неполные данные':'Нет записей'")
    sub("Это расчёт по записям, не прогноз зарплаты.", "Наличие записей не подтверждает полноту доходов. Это расчёт по записям, не прогноз зарплаты.")
    # Explicit cross-links are the only basis for deduplication. Amount/date equality is insufficient.
    sub("amount:p.amount,allocated,partial", "installmentId:plan?.id,installmentPartId:p.id,amount:p.amount,allocated,partial")
    sub("key:'loan:'+row.kind+':'+row.date+':'+row.title", "key:row.kind==='installment'?'installment:'+row.installmentId+':'+row.installmentPartId:'loan:'+row.kind+':'+row.date+':'+row.title")
    sub("link:'loans'}", "link:'loans',installmentId:row.installmentId,installmentPartId:row.installmentPartId}")
    sub("const date=v84DateOfMonth(m,r.day),paid=v84RecurringConfirmed(r,m);", "const linkedPlan=(state.installments||[]).find(i=>i.id===r.installmentId),linkedPart=(linkedPlan?.parts||[]).find(p=>p.id===r.installmentPartId&&String(p.date).startsWith(m));\n  if(linkedPart)continue;\n  const date=v84DateOfMonth(m,r.day),paid=v84RecurringConfirmed(r,m);")
    fn('v86Forecast', '''function v86Forecast(){
 const now=today(),target=v84NextPayDate()||v84DateOfMonth(now.slice(0,7),31),end=target<now?now:target,to=end.slice(0,7);
 // Recurring plans have no historical activation date: include overdue current-period payments,
 // plus explicitly stored older installment/mortgage dates, without inventing past recurrences.
 const months=new Set([now.slice(0,7)]);
 for(const i of state.installments||[])for(const p of i.parts||[])if(String(p.date)<=end)months.add(String(p.date).slice(0,7));
 for(const row of loanScheduleData())if(row.payDate<=end)months.add(row.payDate.slice(0,7));
 let cursor=new Date(now.slice(0,7)+'-01T12:00:00Z');
 while(cursor.toISOString().slice(0,7)<=to){months.add(cursor.toISOString().slice(0,7));cursor.setUTCMonth(cursor.getUTCMonth()+1)}
 const unique=new Map();
 for(const m of [...months].sort())for(const e of v86CalendarEvents(m)){
  if(e.paid||e.date>end||(e.kind==='regular'&&m<now.slice(0,7)))continue;
  if(e.kind==='regular'){
   const linked=state.entries.find(x=>x.recurringId===e.recurringId&&x.recurringPeriod===e.period);
   if(linked&&(state.installments||[]).some(i=>Object.values(i.links||{}).includes(linked.id)))continue;
  }
  unique.set(e.key,e);
 }
 const events=[...unique.values()],remaining=e=>Math.max(0,e.amount-e.allocated);
 const mortgage=events.filter(e=>e.kind==='mortgage'||e.kind==='installment').reduce((n,e)=>n+remaining(e),0);
 const regular=events.filter(e=>e.kind==='regular').reduce((n,e)=>n+remaining(e),0),overdue=events.filter(e=>e.date<now).reduce((n,e)=>n+remaining(e),0),accounts=v86CurrentAccounts();
 return {date:end,accounts,mortgage,regular,overdue,obligations:mortgage+regular,estimate:accounts.total===null?null:accounts.total-mortgage-regular,events};
}''')
    sub("Не учитывает повседневные будущие покупки, изменения доходов и возможное пересечение регулярных платежей с другими графиками.", "Включены просроченные неподтверждённые платежи: ${money(forecast.overdue)}. Регулярные платежи прошлых месяцев без сохранённого графика не восстанавливаются автоматически. Совпадение суммы не означает дубликат; связывайте один платёж явно. Повседневные будущие покупки и изменения доходов не учтены.")
    return patch_early(html)


def patch_early(html):
    body=r'''function simulateEarlyPlan(extras,mode){
 const base=loanScheduleData(),round=n=>Math.round((n+Number.EPSILON)*100)/100;
 if(!base.length||!Array.isArray(extras))return null;
 const sorted=extras.map(x=>({date:String(x.date||''),amount:Number(x.amount)})).sort((a,b)=>a.date.localeCompare(b.date));
 if(sorted.some(x=>!/^\d{4}-\d{2}-\d{2}$/.test(x.date)||!Number.isFinite(x.amount)||x.amount<0||x.date<'2026-09-02'||x.date>base[base.length-1].payDate))return null;
 const positive=sorted.filter(x=>x.amount>0),firstIndex=positive.length?base.findIndex(r=>r.payDate>=positive[0].date):0;
 if(firstIndex<0)return null;
 let bal=firstIndex>0?base[firstIndex-1].balance:4500000,ei=0,interest=0,totalExtra=0,totalUnused=0,totalCharges=0,rows=[];
 for(let i=firstIndex;i<base.length&&bal>.005;i++){
  const bank=base[i],start=parseEarlyDate(i>0?base[i-1].payDate:'2026-09-02'),end=parseEarlyDate(bank.payDate),baseStart=i>0?base[i-1].balance:4500000,totalDays=Math.max(1,(end-start)/86400000);
  let cursor=start;
  while(ei<positive.length&&parseEarlyDate(positive[ei].date)<=end){
   const ex=positive[ei++],date=parseEarlyDate(ex.date),days=Math.max(0,(date-cursor)/86400000),accrued=round(Number(bank.interest)*(days/totalDays)*(bal/Math.max(baseStart,1))),applied=Math.min(bal,round(ex.amount)),unused=round(ex.amount-applied);
   interest=round(interest+accrued);totalExtra=round(totalExtra+applied);totalUnused=round(totalUnused+unused);bal=round(Math.max(0,bal-applied));
   rows.push({date:ex.date,kind:'extra',scheduled:0,extra:applied,requested:ex.amount,unused,total:round(applied+accrued),interest:accrued,charges:0,body:applied,balance:bal});cursor=date;
   if(bal<=.005)break;
  }
  if(bal<=.005)break;
  const accrued=round(Number(bank.interest)*(Math.max(0,(end-cursor)/86400000)/totalDays)*(bal/Math.max(baseStart,1))),charges=round(Math.max(0,Number(bank.payment)-Number(bank.body)-Number(bank.interest)));
  let payment=Number(bank.payment);
  if(mode==='payment'&&totalExtra>0){const remaining=Math.max(1,base.length-i),rate=Number(bank.interest)/Math.max(baseStart,1),annuity=rate>0?bal*rate/(1-Math.pow(1+rate,-remaining)):bal/remaining;payment=Math.min(payment,round(annuity+charges))}
  const body=round(Math.min(bal,Math.max(0,payment-accrued-charges))),actual=round(body+accrued+charges);
  bal=round(Math.max(0,bal-body));interest=round(interest+accrued);totalCharges=round(totalCharges+charges);
  rows.push({date:bank.payDate,kind:'scheduled',scheduled:actual,extra:0,unused:0,total:actual,interest:accrued,charges,body,balance:bal});
 }
 // Later planned extras after payoff remain unused; they are never principal.
 for(;ei<positive.length;ei++){const ex=positive[ei];totalUnused=round(totalUnused+ex.amount);rows.push({date:ex.date,kind:'unused',scheduled:0,extra:0,requested:ex.amount,unused:ex.amount,total:0,interest:0,charges:0,body:0,balance:bal})}
 const paidRows=rows.filter(r=>r.kind!=='unused'),last=paidRows[paidRows.length-1],oldInterest=round(base.slice(firstIndex).reduce((a,r)=>a+Number(r.interest),0)),oldScheduledCount=base.length-firstIndex,newScheduled=rows.filter(r=>r.kind==='scheduled');
 return {rows,oldInterest,totalInterest:interest,totalExtra,totalUnused,totalCharges,totalCash:round(rows.reduce((n,r)=>n+r.total,0)),remainingBalance:bal,endDate:last?.date||base[base.length-1].payDate,monthsSaved:Math.max(0,oldScheduledCount-newScheduled.length),firstBalance:rows.find(r=>r.kind==='extra')?.balance??null,oldEndDate:base[base.length-1].payDate};
}'''
    html=replace_function(html,'simulateEarlyPlan',body)
    html=replace_function(html,'renderEarlyPlanRows',r'''function renderEarlyPlanRows(){
 const wrap=document.getElementById('earlyPlanRows');if(!wrap)return;
 const sim=simulateEarlyPlan(getEarlyPayments(),document.getElementById('earlyMode')?.value||'term'),available=(sim?.rows||[]).filter(r=>r.kind==='extra'||r.kind==='unused');
 [...wrap.querySelectorAll('.early-plan-row[data-extra-row]')].forEach((row,i)=>{
  const n=row.querySelector('.early-plan-num');if(n)n.textContent=i+1;
  const amount=Math.max(0,Number(row.querySelector('.early-plan-amount')?.value)||0),date=row.querySelector('.early-plan-date')?.value||'',index=available.findIndex(r=>r.date===date&&r.requested===amount),payment=index>=0?available.splice(index,1)[0]:null;
  const out=row.querySelector('.early-plan-total');if(out)out.textContent=payment?money2(payment.total)+(payment.unused>0?' · не использовано '+money2(payment.unused):''):'—';
 });
}''')
    # All summary fields show the same capped model as the result table.
    html=html.replace("const firstTotal=first&&base?Number(base.payment)+first.amount:0;", "const sim=first?simulateEarlyPlan(extras,document.getElementById('earlyMode')?.value||'term'):null,firstRow=sim?.rows.find(r=>r.kind==='extra');\n const firstTotal=firstRow?.total||0;")
    html=html.replace("const planTotal=extras.reduce((a,x)=>a+x.amount,0);", "const planTotal=sim?.totalExtra||0;")
    html=html.replace("money2(Math.max(0,prevBal-first.amount))", "money2(sim?.firstBalance??prevBal)")
    html=html.replace("firstExtra&&nextScheduled?firstExtra.extra+nextScheduled.scheduled:firstExtra?.extra||0", "firstExtra?.total||0")
    html=html.replace("r.kind==='extra'?' Досрочно':'По графику'", "r.kind==='extra'?'Досрочно':r.kind==='unused'?'Не использовано':'По графику'")
    html=html.replace("<td>${money2(r.extra)}</td><td><b>${money2(r.total)}</b>", "<td>${money2(r.extra)}</td><td>${money2(r.interest)}</td><td>${money2(r.charges)}</td><td>${money2(r.unused)}</td><td><b>${money2(r.total)}</b>")
    html=html.replace("<th>Дополнительно</th><th>Всего</th>", "<th>В тело досрочно</th><th>Проценты</th><th>Прочие начисления</th><th>Не использовано</th><th>Всего</th>")
    html=html.replace("<span>сверх обязательных</span>", "<span>применено в тело · не использовано ${money2(sim.totalUnused)}</span>")
    html=html.replace("Чем точнее даты и суммы вашего плана, тем полезнее сравнение.", "Досрочная сумма означает взнос в тело; начисленные до этой даты проценты показаны отдельно и включены в общую сумму. Превышение остатка не применяется в тело. Прочие начисления банковского графика не уменьшают основной долг. Это оценка: сумму полного закрытия и дополнительные начисления подтвердит банк.")
    html=html.replace("endDate=last?fmtDate(last.date):'—'", "endDate=fmtDate(sim.endDate)")
    html=html.replace("(nextScheduled?money2(nextScheduled.scheduled):money2(state.settings?.loans?.loan1||85885))", "(nextScheduled?money2(nextScheduled.scheduled):'Закрыт по модели')")
    html=html.replace("money2(nextScheduled?.scheduled||85885)", "money2(loanScheduleData().find(r=>r.payDate>=(firstExtra?.date||today()))?.payment||0)")
    html=html.replace("<span>основной + досрочный</span>", "<span>в тело и начисленные проценты</span>")
    html=html.replace("Внесу в выбранную дату", "Первый досрочный взнос")
    html=html.replace("<span>Итого в дату</span>", "<span>Взнос и проценты</span>")
    html=html.replace("<span>Дополнительно, ₽</span>", "<span>В тело досрочно, ₽</span>")
    html=html.replace("Дополнительная сумма</label>", "Досрочно в тело</label>")
    html=html.replace("min=\"2026-09-01\"", "min=\"2026-09-02\"")
    html=html.replace("Всего внесу в ближайшую дату", "В дату первого досрочного платежа")
    html=html.replace("основной + дополнительный", "досрочно в тело + начисленные проценты")
    return html


if __name__=='__main__':
    source=Path(sys.argv[1]);target=Path(sys.argv[2]);target.write_text(patch(source.read_text()))
