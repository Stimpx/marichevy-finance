"""Apply PR4 only to an explicit HTML copy. Does not touch git or source by default."""
from pathlib import Path
import argparse
import re


def replace_function(html, name, next_marker, source):
    start = html.index('function '+name+'(')
    end = html.index(next_marker, start)
    return html[:start]+source.strip()+'\n'+html[end:]


def clean_form_css(css):
    """Remove superseded entry rules, preserving unrelated selectors and media content."""
    def split_selectors(value):
        out=[];depth=0;start=0
        for i,ch in enumerate(value):
            if ch in '([': depth+=1
            elif ch in ')]': depth-=1
            elif ch==',' and depth==0: out.append(value[start:i]);start=i+1
        return out+[value[start:]]
    def obsolete(selector):
        s=re.sub(r'/\*.*?\*/','',selector,flags=re.S).strip()
        if s.startswith('#today'):
            return not ('v91-transaction' in s or 'v91-row-actions' in s or '.card:not(.v91-entry)' in s)
        return any(s.startswith(x) for x in ['.v90-chips','#v90Categories','#v90Search','#v90Extra','#v90Save','#eAmount','.v91-kicker'])
    out=[];pos=0
    while pos<len(css):
        opening=css.find('{',pos)
        if opening<0: out.append(css[pos:]);break
        selector=css[pos:opening];depth=1;end=opening+1
        while end<len(css) and depth:
            if css[end]=='{':depth+=1
            elif css[end]=='}':depth-=1
            end+=1
        body=css[opening+1:end-1]
        normalized=re.sub(r'/\*.*?\*/','',selector,flags=re.S).strip()
        if normalized.startswith('@'):
            if normalized.startswith(('@media','@supports','@layer')):
                body=clean_form_css(body)
            out.append(selector+'{'+body+'}')
        else:
            keep=[s for s in split_selectors(selector) if not obsolete(s)]
            if keep: out.append(','.join(keep)+'{'+body+'}')
        pos=end
    return ''.join(out)


def transform(html):
    if 'id="v95ExpenseStyle"' in html:
        raise ValueError('PR4 already applied')
    start = html.index('<div class="form-grid v91-form">')
    end = html.index('<div class="actions v91-actions">', start)
    form = html[start:end]
    lines = form.splitlines()
    operation = lines[1].replace('class="field"', 'class="field full v95-operation"', 1)
    amount = lines[2].replace('class="field"', 'class="field v95-amount"', 1).replace('Сумма, ₽','Сколько, ₽')
    category = lines[3].replace('expense-field full v91-category','expense-field v91-category').replace('На что потратили?','Что купили?').replace('Например: жвачка, хлеб, бензин','Молоко, обед, корм…')
    category = category.replace('<small id="v92SearchHint" role="status" aria-live="polite"></small>', '').replace('<div id="v90Quick" class="v90-chips"></div>', '')
    browse_start = category.index('<div id="v90Categories">')
    browse_end = category.index('<div id="v93CreditHelp"')
    browse = category[browse_start:browse_end]
    category = category[:browse_start]+category[browse_end:]
    beneficiary = lines[4].replace('expense-field full','expense-field').replace('Для кого покупка?','Для кого?')
    beneficiary = beneficiary.replace('<small class="v81-field-note">Кому купили, а не кто приложил карту.</small>', '')
    merchant = next(x for x in lines if 'id="eStore"' in x).replace('Где купили?', 'Где? · необязательно')
    detail = form[form.index('<details'):]
    detail = '\n'.join(x for x in detail.splitlines() if 'id="eStore"' not in x)
    detail = detail.replace('Добавить детали <span>место, описание, дата</span>', 'Детали <span>дата, оплата, комментарий</span>').replace('Что купили / заметка','Комментарий · необязательно')
    supporting = '\n'.join(lines[5:9])
    quick = '<div class="field expense-field full v95-suggestions"><small id="v92SearchHint" role="status" aria-live="polite"></small><div id="v90Quick" class="v90-chips"></div>'+browse+'</div>'
    html = html[:start]+'\n'.join([lines[0],operation,amount,category,beneficiary,merchant,quick,supporting,detail])+'\n'+html[end:]
    html = html.replace('<h2>Новая запись</h2><p>Пара деталей — и покупка в истории.</p>', '<h2>Новая запись</h2><p>Сумма, покупка и для кого — остальное по желанию.</p>', 1)
    # Existing edit dialogs retain legacy beneficiary choices, including unknown values.
    a=html.index('function v81FillDetails(')
    b=html.index('function v81EntryDetailText(',a)
    block=html[a:b].replace("const target=beneficiary===undefined?(who.value||'Не указано'):(beneficiary||'Не указано');", "const target=beneficiary===undefined?(who.value||(prefix==='e'?'Общее':'Не указано')):(beneficiary||(prefix==='e'?'Общее':'Не указано'));")
    block=block.replace('const choices=v81BeneficiaryOptions();', "const choices=prefix==='e'?['Общее',...['Сергей','Виктория','Алиса','Майя'],...PEOPLE.filter(x=>!['Общее','Сергей','Виктория','Алиса','Майя'].includes(x))]:v81BeneficiaryOptions();")
    block=block.replace("x==='Общее'?'Всей семье':x", "x")
    html=html[:a]+block+html[b:]
    html=html.replace("v81FillDetails('e','','','Не указано');", "v81FillDetails('e','','','Общее');")
    # Preserve the original choose/search behavior, adding optional shortcuts on top.
    a=html.index('function v90Choose(')
    b=html.index('function v90Paint(',a)
    block=html[a:b].replace('function v90Choose(key){','function v90Choose(key,detail=\'\',description=\'\'){').replace("v81FillDetails('e',key);", "v81FillDetails('e',key,detail);if(description&&!q){comment.value=description;v92AutoDescription=description;}")
    html=html[:a]+block+html[b:]
    html=replace_function(html,'v90Paint','function v90Template(',r'''
function v90Paint(){
 const selected=document.getElementById('eCategory').value,q=document.getElementById('v90Search').value.trim();
 const variants=[
  {key:'Продукты',label:'Продукты'},
  {key:'Вкусняшки',label:'Вкусняшки'},
  {key:'Школа и занятия',label:'Школьное питание',detail:'Школьное питание'},
  {key:'Школа и занятия',label:'Английский',detail:'Английский язык'},
  {key:'Школа и занятия',label:'Танцы',detail:'Танцы'},
  {key:'Животные',label:'Корм питомцу',detail:'Корм'},
  {key:'Подарки',label:'Подарок'},
  {key:'Рестораны и кафе',label:'Ресторан',detail:'Ресторан'},
  {key:'Рестораны и кафе',label:'Чаевые',description:'Чаевые'}
 ];
 const matches=v92Matches(q),hasQuery=Boolean(q),allCategories=V90_CATEGORIES.map(([key,label])=>({key,label}));
 let items=hasQuery?(matches.length?matches:allCategories):(v91Expanded?allCategories:variants);
 if(hasQuery&&matches.length){const relevant=variants.filter(x=>v92Norm(x.label).includes(v92Norm(q))||v92Norm(q).includes(v92Norm(x.label)));items=[...relevant,...items.filter(x=>!relevant.some(v=>v.key===x.key))]}
 const currentDetail=document.getElementById('eSubcategory').value;
 document.getElementById('v90Quick').innerHTML=items.map(({key,label,detail},i)=>{const active=selected===key&&(!detail||currentDetail===detail);return `<button type="button" class="btn small ${active?'primary':''}" aria-pressed="${active}" data-cat="${esc(key)}" data-choice="${i}"><span>${esc(label)}</span></button>`}).join('');
 const hint=document.getElementById('v92SearchHint');
 hint.textContent=hasQuery?(matches.length?'Выберите подходящий вариант.':'Выберите категорию для этой покупки.'):'Быстрые варианты или поиск покупки';
 const status=document.getElementById('v92Selected');status.hidden=!selected;
 status.textContent=selected?'Выбрано: '+(V90_CATEGORIES.find(x=>x[0]===selected)?.[1]||selected)+(currentDetail?' · '+currentDetail:''):'';
 document.getElementById('v93CreditHelp').hidden=selected!=='Кредит';
 const all=document.getElementById('v91All');all.textContent=v91Expanded?'Быстрые варианты':'Все категории';all.setAttribute('aria-expanded',String(v91Expanded));
 document.querySelectorAll('#v90Quick [data-choice]').forEach(b=>b.onclick=()=>{const item=items[Number(b.dataset.choice)];v90Choose(item.key,item.detail||'',item.description||'')});
}
''')
    html=html.replace("function updateEntryForm(){\n const type=document.getElementById('eType').value;", "function updateEntryForm(){\n const type=document.getElementById('eType').value;\n document.querySelector('.v91-form').dataset.entryType=type;", 1)
    # The old template row duplicated shortcuts and assigned recipients implicitly.
    a=html.index('<div id="v90Templates"')
    b=html.index('</div>',a)+6
    html=html[:a]+'<div id="v90Templates" hidden></div>'+html[b:]
    html=html.replace("['Вкусняшки','','Не указано','','']", "['Вкусняшки','','Общее','','']")
    html=re.sub(r'(<style(?:\s[^>]*)?>)(.*?)(</style>)',lambda m:m[1]+clean_form_css(m[2])+m[3],html,flags=re.S)
    css='''
<style id="v95ExpenseStyle">
#today .v91-entry{max-width:1120px;margin:0 auto 24px;border:1px solid #e3e7ec;border-radius:24px;padding:28px;background:#fff;box-shadow:0 8px 30px #162c4610}
#today .v91-head h2{font-size:26px;font-weight:700;letter-spacing:-.6px;margin:5px 0 6px}
#today .v91-head p{color:#718096;font-size:14px;margin:0}
#today .v91-kicker{font-size:10px;letter-spacing:1.5px;color:#6a778b;font-weight:650}
#today .v91-form{display:grid;grid-template-columns:170px minmax(180px,1.6fr) minmax(140px,1fr) minmax(150px,1fr);align-items:start;gap:16px;margin-top:22px}
#today .v91-form>.field{grid-column:auto;min-width:0;margin:0}
#today .v91-form>.field.full{grid-column:1/-1}
#today .v91-form .field label{display:block;font-size:13px;color:#48566a;font-weight:600;min-height:20px;margin-bottom:7px;line-height:1.4}
#today .v91-form input,#today .v91-form select{width:100%;min-width:0;font-size:16px;min-height:50px;border-radius:12px;background-color:#fafbfc;border:1px solid #e0e5eb;font-weight:400;padding:10px 14px}
#today .v91-form #eAmount{font-size:24px;font-weight:600;height:50px}
#today .v91-form .v95-operation{max-width:280px}
#today .v91-form .v95-operation select{min-height:40px;font-size:14px}
#today .v91-form #v90Search{margin:0;padding:12px 14px}
#today .v91-form .v90-chips{display:flex;flex-wrap:wrap;gap:7px;margin:9px 0 0}
#today .v91-form .v90-chips button{display:flex;align-items:center;justify-content:center;min-width:0;min-height:36px;padding:7px 11px;border:1px solid #e3e8ee;border-radius:9px;background:#f7f8fa;color:#415068;font-size:12px;font-weight:550;box-shadow:none;line-height:1.3;text-align:center;white-space:normal}
#today .v91-form .v90-chips button.primary{background:#edf1ff;border-color:#8999e7;color:#304dc1}
#today .v95-suggestions small{color:var(--muted);font-size:11px}
#today #v92Selected{font-size:11px;line-height:1.4;margin:7px 0 0;overflow-wrap:anywhere}
#today #v90Categories{margin-top:8px}
#today .v91-link{background:none;color:#415fc3;font-size:12px;padding:5px 0;min-height:30px}
#today #v90Extra{border-top:1px solid #e9edf1;padding-top:16px}
#today #v90Extra summary{font-size:14px;cursor:pointer;color:#43536b;padding:4px 0}
#today #v90Extra summary span{font-size:12px;color:#8590a0;margin-left:8px}
#today #v90Extra .form-grid{display:grid;margin-top:14px;gap:14px;grid-template-columns:repeat(2,minmax(0,1fr))}
#today #v90Extra .field.full{grid-column:1/-1}
#today .v91-actions{display:flex;align-items:center;gap:10px;margin-top:20px}
#today .v91-actions .btn{flex:0 0 auto;font-size:14px;font-weight:600;min-height:48px;border-radius:12px}
#today .v91-actions .primary{background:#304fc7;box-shadow:none;flex:1 1 auto}
#today .v91-entry button:focus-visible,#today .v91-entry summary:focus-visible{outline:3px solid #91a9ed;outline-offset:3px}
@media(max-width:1000px){#today .v91-form{grid-template-columns:repeat(2,minmax(0,1fr))}#today .v91-form>.v95-amount,#today .v91-form>.v91-category{grid-column:1/-1}}
@media(max-width:600px){#today .v91-entry{padding:16px;border-radius:20px}#today .v91-form{gap:12px 10px;margin-top:16px}#today .v91-head h2{font-size:24px}#today .v91-head p{font-size:12px}#today .v91-kicker{display:none}#today .v91-form .field label{font-size:12px}#today .v91-form .v90-chips button{font-size:11px;padding:6px 9px}#today .v91-actions{margin-top:16px}#today #v90Extra summary span{display:none}}
@media(max-width:440px){#today #v90Extra .form-grid{grid-template-columns:1fr}}
</style>
'''
    return html.replace('</head>',css+'</head>',1)


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('source',type=Path)
    p.add_argument('output',type=Path)
    args=p.parse_args()
    if args.source.resolve()==args.output.resolve():
        p.error('Use a separate output HTML for review')
    args.output.write_text(transform(args.source.read_text()))
